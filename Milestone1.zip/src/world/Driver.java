package world;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Driver class to check functionality.
 */
public class Driver {

  public static String filename;


  public static void setFilename(String file) {

    filename = file;
  }
  /**
  * main method.
  * @param args to take cmd input.
  */

  public static void main(String[] args) {
    filename = args[0];
    World world;
    Room room;
    try {
      world = new World(36, 30, 50);
      room = new Room(21, 20);
      System.out.println("Total rows : " + world.getTotalRows());
      System.out.println("Total columns : " + world.getTotalColumns());
      System.out.println("Total Health of Target : " + world.getTotalHealth());
      System.out.println("Name of mansion and Target : " + world.toString());
      System.out.println("Total rooms : " + room.getTotalRooms());
      System.out.println("Total items : " + room.getTotalItems());
      System.out.println("Get neighbors of space Dining Hall : "
          + room.getneighbours("Dining Hall"));
      System.out.println("Get list of items and their damage values for Nursery : "
          + room.getitemdamage("Nursery"));
      room.buildbufferimage();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }








}
